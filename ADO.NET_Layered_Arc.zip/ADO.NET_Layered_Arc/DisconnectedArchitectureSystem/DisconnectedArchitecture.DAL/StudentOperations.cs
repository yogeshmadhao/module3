﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DisconnectedArchitecture.Entity;
using DisconnectedArchitecture.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace DisconnectedArchitecture.DAL
{
    public class StudentOperations
    {
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        static SqlDataAdapter da;
        static DataSet ds = new DataSet();
        //Function to insert student record in database
        public static int InsertStudent(Student stud)
        {
            int records = 0;

            try
            {
                //Creating command object
                da = new SqlDataAdapter("usp_InsertStudent", con);

                DataRow dr = ds.Tables["Student"].NewRow();

                dr["Stud_Code"] = stud.StudCode;
                dr["Stud_Name"] = stud.StudName;
                dr["Dept_Code"] = stud.DeptCode;
                dr["Stud_Dob"] = stud.DOB;
                dr["Address"] = stud.Address;


                ds.Tables["Student"].Rows.Add(dr);

                 records = da.Update(ds, "Student");
                
               
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

    }
}
