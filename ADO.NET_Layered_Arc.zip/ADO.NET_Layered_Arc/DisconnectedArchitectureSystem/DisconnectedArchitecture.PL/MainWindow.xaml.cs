﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DisconnectedArchitecture.Entity;
using DisconnectedArchitecture.Exceptions;
using DisconnectedArchitecture.BL;

namespace DisconnectedArchitecture.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        List<Student> studList = new List<Student>();
        public void Show()
        {
            dgStudent.DataContext = studList;

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {

            Student stud = new Student();

            stud.StudCode = Convert.ToInt32(txtStudCode.Text);
            stud.StudName = txtStudName.Text;
            stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
            stud.DOB = Convert.ToDateTime(txtStudDob.Text);
            stud.Address = txtStudAddress.Text;

            int recordsAffected = Validations.InsertStudent(stud);
            studList.Add(stud);
            if (recordsAffected > 0)
            {
                MessageBox.Show("Record inserted successfully");
                Show();
            }
        }
    }
}
