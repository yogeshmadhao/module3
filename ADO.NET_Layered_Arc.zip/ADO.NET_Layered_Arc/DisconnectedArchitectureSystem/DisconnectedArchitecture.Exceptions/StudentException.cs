﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DisconnectedArchitecture.Exceptions
{
    public class StudentException:ApplicationException
    {

        //Default constructor
        public StudentException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public StudentException(string message)
            : base(message)
        { }
    }
}
