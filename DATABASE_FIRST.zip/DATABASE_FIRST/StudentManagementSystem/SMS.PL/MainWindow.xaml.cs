﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        public void ShowData()
        {
            try 
            {
                dgStudent.DataContext = StudentValidation.GetAllStudents();
            }
            catch (Student_masterException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                Student_master stud = new Student_master();
                stud.Stud_Code = Convert.ToDecimal(txtStudCode.Text);
                stud.Stud_Name = txtStudName.Text;
                stud.Dept_Code = Convert.ToDecimal(txtDeptCode.Text);
                stud.Stud_Dob = Convert.ToDateTime(txtDOB.Text);
                stud.Address = txtAddress.Text;
                stud.Stud_Year = Convert.ToInt32(txtYear.Text);

                int records = StudentValidation.AddStudent(stud);

                if (records > 0)
                {
                    MessageBox.Show("Student record added successfully");
                    ShowData();
                    Clear();
                }
                else
                    throw new Student_masterException("Student record not added");
            }
            catch (Student_masterException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Clear()
        {
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDeptCode.Text = "";
            txtDOB.Text = DateTime.Today.ToShortDateString();
            txtAddress.Text = "";
            txtYear.Text = "";

            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;

            txtStudCode.IsReadOnly = false;
            txtStudName.IsReadOnly = false;
            txtDOB.IsEnabled = true;
            txtYear.IsReadOnly = false;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                int scode = Convert.ToInt32(txtStudCode.Text);

                Student_master stud = StudentValidation.SearchStudent(scode);

                if (stud != null)
                {
                    btnUpdate.IsEnabled = true;
                    btnDelete.IsEnabled = true;
                    gridStudent.DataContext = stud;
                }
                else
                    throw new Student_masterException("Student record not found");

            }
            catch (Student_masterException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                Student_master stud = new Student_master();
                stud.Stud_Code = Convert.ToDecimal(txtStudCode.Text);
                stud.Stud_Name = txtStudName.Text;
                stud.Dept_Code = Convert.ToDecimal(txtDeptCode.Text);
                stud.Stud_Dob = Convert.ToDateTime(txtDOB.Text);
                stud.Address = txtAddress.Text;
                stud.Stud_Year = Convert.ToInt32(txtYear.Text);

                int records = StudentValidation.UpdateStudent(stud);

                if (records > 0)
                {
                    MessageBox.Show("Student record updated successfully");
                    ShowData();
                    Clear();
                }
                else
                    throw new Student_masterException("Student record not updated");
            }
            catch (Student_masterException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                int scode = Convert.ToInt32(txtStudCode.Text);

                int records = StudentValidation.DeleteStudent(scode);

                if (records > 0)
                {
                    MessageBox.Show("Student record deleted successfully");
                    ShowData();
                    Clear();
                }
                else
                {
                    throw new Student_masterException("Student record not deleted");
                }
            }
            catch (Student_masterException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {
            try { }
            catch (Student_masterException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
