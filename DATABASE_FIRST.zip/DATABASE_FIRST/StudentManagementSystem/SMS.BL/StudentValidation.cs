﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;

namespace SMS.BL
{
    public class StudentValidation
    {
        public static bool ValidateStudent(Student_master stud)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try 
            {
                //if (stud.Stud_Code < 1000 || stud.Stud_Code > 9999)
                //{
                //    message.Append("Student code should be 4 digits long\n");
                //    studValidated = false;
                //}

                if (stud.Stud_Name.Trim() == String.Empty)
                {
                    message.Append("Student Name should be provided\n");
                    studValidated = false;
                }
                else if (!Regex.IsMatch(stud.Stud_Name, "[A-Z][a-z]+"))
                {
                    message.Append("Student Name should start with Capital letter and it should have alphabets only");
                    studValidated = false;
                }

                if (studValidated == false)
                    throw new Student_masterException(message.ToString());
            }
            catch (Student_masterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static int AddStudent(Student_master stud)
        {
            int records = 0;

            try 
            {
                if (ValidateStudent(stud))
                {
                    records = StudentOperations.AddStudent(stud);
                }
                else
                    throw new Student_masterException("Please provide valid information");
            }
            catch (Student_masterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static int UpdateStudent(Student_master stud)
        {
            int records = 0;

            try
            {
                if (ValidateStudent(stud))
                {
                    records = StudentOperations.UpdateStudent(stud);
                }
                else
                    throw new Student_masterException("Please provide valid information");
            }
            catch (Student_masterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static int DeleteStudent(int scode)
        {
            int records = 0;

            try 
            {
                records = StudentOperations.DeleteStudent(scode);
            }
            catch (Student_masterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static Student_master SearchStudent(int scode)
        {
            Student_master stud = null;

            try
            {
                stud = StudentOperations.SearchStudent(scode);
            }
            catch (Student_masterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student_master> GetAllStudents()
        {
            List<Student_master> studList = new List<Student_master>();

            try 
            {
                studList = StudentOperations.GetAllStudent();
            }
            catch (Student_masterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
