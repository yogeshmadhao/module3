﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace BookTransactionDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        TrainingEntities context = new TrainingEntities();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgBooks.DataContext = context.Book_Master.ToList();

            cbStudent.DataContext = context.Student_master.ToList();
        }

        private void dgBooks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //System.Data.DataRow dr = ((DataRowView)dgBooks.SelectedItem).Row;

            //Book_Master book = new Book_Master();
            //book.Book_code = Convert.ToDecimal(dr["Book_code"]);
            //book.Book_name = dr["Book_name"].ToString();
            //book.pub_year = Convert.ToInt32(dr["pub_year"]);
            //book.Author = dr["Author"].ToString();
            //book.book_category = dr["book_category"].ToString();
            //book.Price = Convert.ToDecimal(dr["Price"]);

            Book_Master book = (Book_Master)dgBooks.SelectedItem;

            gridBook.DataContext = book;
        }
    }
}
