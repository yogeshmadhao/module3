﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using product.Entity;
using Product.Exception;

namespace Product.DAL
{
    public class ProductOperations
    {
        static ProductContext context = new ProductContext();
        public static int AddProduct(Product12 p )
        {
            int records = 0;

            try
            {
                context.Products.Add(p);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static List<Product12> GetAllStudent()
        {
            List<Product12> studList = null;

            try
            {
                studList = context.Products.ToList<Product12>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }

    }
}
