﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using product.Entity;
using Product.Exception;
using Product.DAL;

namespace Product.BL
{
    public class ProductValidations
    {
        public static bool ValidateStudent(Product12 stud)
        {
            bool studValidated = true;
            return studValidated;
        }
        public static int AddStudent(Product12 stud)
        {
            int records = 0;

            try
            {
                if (ValidateStudent(stud))
                {
                    records = ProductOperations.AddProduct(stud);
                }
                else
                    throw new PRoductException("Please provide valid information");
            }
            catch (PRoductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static List<Product12> GetAllStudents()
        {
            List<Product12> studList = new List<Product12>();

            try
            {
                studList = ProductOperations.GetAllStudent();
            }
            catch (PRoductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
