﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product.Exception
{
    public class PRoductException:ApplicationException
    {
        public PRoductException():base()
        { }

        public PRoductException(string message)
            : base(message)
        { }
    }
}
