﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace product.Entity
{
    public class ProductContext:DbContext
    {
        public DbSet<Product12> Products { get; set; }
    }
}
