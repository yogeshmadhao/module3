﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations; 
namespace product.Entity
{
    public class Product12
    {
        [Key]
        public int id { get; set; }
        public string  name { get; set; }
        public string  Category { get; set; }
        public decimal Price { get; set; }
   }
}
