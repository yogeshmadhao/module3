﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDM.Entity;
using PDM.Exception;
using System.Data.SqlClient;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace PDM.DAL
{
    public class ProductOperations
    {
       static ProductModelContainer context = new ProductModelContainer();
       
        public static int AddProduct(PProduct_138314 prod)
        {
            int records = 0;

            try
            {

                context.PProducts.Add(prod);
                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            
           return records;
        }
        public static List<PProduct_138314> GetAllProducts()
        {
            List<PProduct_138314> prodList = null;

            try
            {
                prodList = context.PProducts.ToList<PProduct_138314>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }
    }
}
