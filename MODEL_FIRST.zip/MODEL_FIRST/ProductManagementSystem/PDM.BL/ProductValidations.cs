﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDM.DAL;
using PDM.Entity;
using PDM.Exception;
using System.Text.RegularExpressions;

namespace PDM.BL
{
    public class ProductValidations
    {
        public static bool ValidateProduct(PProduct_138314 prod)
        {
            bool prodValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //if (stud.Stud_Code < 1000 || stud.Stud_Code > 9999)
                //{
                //    message.Append("Student code should be 4 digits long\n");
                //    studValidated = false;
                //}

                if (prod.Name.Trim() == String.Empty)
                {
                    message.Append("Product Name should be provided\n");
                    prodValidated = false;
                }
                else if (!Regex.IsMatch(prod.Name, "[A-z]+"))
                {
                    message.Append("Product Name should start with Capital letter and it should have alphabets only");
                    prodValidated = false;
                }

                if (prodValidated == false)
                    throw new ProductException(message.ToString());
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodValidated;
        }
        public static int AddProduct(PProduct_138314 prod)
        {
            int records = 0;

            try
            {
                if (ValidateProduct(prod))
                {
                    records = ProductOperations.AddProduct(prod);
                }
                else
                    throw new ProductException("Please provide valid information");
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }
        public static List<PProduct_138314> GetAllProducts()
        {
            List<PProduct_138314> prodList = new List<PProduct_138314>();

            try
            {
                prodList = ProductOperations.GetAllProducts();
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }
    }
}
